import os


def count_lines(file_path):
    """统计单个文件的代码行数"""
    total_lines = 0
    code_lines = 0

    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()
            total_lines = len(lines)

            for line in lines:
                # 去除前后空白
                line = line.strip()
                # 跳过空行
                if not line:
                    continue
                # 跳过注释行
                if line.startswith('#'):
                    continue
                # 跳过多行注释
                if line.startswith('"""') or line.startswith("'''"):
                    continue
                code_lines += 1

    except Exception as e:
        print(f"无法读取文件 {file_path}: {str(e)}")
        return 0, 0

    return total_lines, code_lines


def main():
    total_all = 0
    code_all = 0
    python_files = []
    current_script = os.path.basename(__file__)  # 获取当前脚本的文件名

    # 遍历所有目录
    for root, dirs, files in os.walk('.'):
        # 跳过 __pycache__ 目录
        if '__pycache__' in root:
            continue

        for file in files:
            # 排除当前的统计脚本
            if file == current_script:
                continue

            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                python_files.append(file_path)
                total, code = count_lines(file_path)
                total_all += total
                code_all += code
                print(f"\n文件: {file_path}")
                print(f"总行数: {total}")
                print(f"有效代码行数: {code}")

    print("\n统计总结:")
    print(f"发现的Python文件数量: {len(python_files)}")
    print(f"所有Python文件的总行数: {total_all}")
    print(f"所有Python文件的有效代码行数: {code_all}")


if __name__ == '__main__':
    main()
