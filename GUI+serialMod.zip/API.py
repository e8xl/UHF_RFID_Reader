import serial
import time
from typing import List, Tuple, Optional

class RFID_API:
    # 常量定义
    HEADER = 0xBB
    END = 0x7E
    
    # 帧类型
    COMMAND_FRAME = 0x00  # 命令帧
    RESPONSE_FRAME = 0x01  # 响应帧
    NOTIFY_FRAME = 0x02   # 通知帧
    
    def __init__(self, port: str, baudrate: int = 115200):
        """初始化RFID API
        
        Args:
            port: 串口号
            baudrate: 波特率
        """
        self.serial = serial.Serial(port, baudrate)
        
    def _calculate_checksum(self, data: bytes) -> int:
        """计算校验和
        
        Args:
            data: 需要计算校验和的数据(从Type到Parameter)
            
        Returns:
            校验和的最低字节
        """
        return sum(data) & 0xFF
    
    def start_multi_inventory(self, count: int = 10000) -> bool:
        """开始多次轮询(群读)
        
        Args:
            count: 轮询次数(0-65535)
            
        Returns:
            是否成功发送命令
        """
        # 构建命令帧
        cmd_type = self.COMMAND_FRAME
        cmd_code = 0x27
        reserved = 0x22
        count_msb = (count >> 8) & 0xFF
        count_lsb = count & 0xFF
        
        # 参数部分
        params = bytes([reserved, count_msb, count_lsb])
        param_len = len(params)
        
        # 计算校验和
        data_for_checksum = bytes([cmd_type, cmd_code, 0x00, param_len]) + params
        checksum = self._calculate_checksum(data_for_checksum)
        
        # 完整的命令帧
        command = bytes([self.HEADER, cmd_type, cmd_code, 0x00, param_len]) + params + bytes([checksum, self.END])
        
        try:
            self.serial.write(command)
            return True
        except:
            return False
            
    def read_tag_data(self) -> Optional[dict]:
        """读取标签数据(通知帧)
        
        Returns:
            包含标签信息的字典,如果读取失败返回None
        """
        try:
            # 等待接收数据
            if self.serial.in_waiting:
                # 读取帧头
                if self.serial.read(1)[0] != self.HEADER:
                    return None
                    
                # 读取帧类型
                frame_type = self.serial.read(1)[0]
                
                if frame_type == self.NOTIFY_FRAME:
                    # 读取完整的通知帧
                    command = self.serial.read(1)[0]
                    length_msb = self.serial.read(1)[0]
                    length_lsb = self.serial.read(1)[0]
                    length = (length_msb << 8) | length_lsb
                    
                    # 读取数据部分
                    data = self.serial.read(length)
                    checksum = self.serial.read(1)[0]
                    end = self.serial.read(1)[0]
                    
                    if end != self.END:
                        return None
                        
                    # 解析数据
                    rssi = data[0]
                    pc = (data[1] << 8) | data[2]
                    epc = data[3:-2]
                    crc = (data[-2] << 8) | data[-1]
                    
                    return {
                        'rssi': rssi,
                        'pc': pc,
                        'epc': epc.hex().upper(),
                        'crc': crc
                    }
                    
                elif frame_type == self.RESPONSE_FRAME:
                    # 处理响应帧
                    command = self.serial.read(1)[0]
                    length_msb = self.serial.read(1)[0]
                    length_lsb = self.serial.read(1)[0]
                    parameter = self.serial.read(1)[0]
                    checksum = self.serial.read(1)[0]
                    end = self.serial.read(1)[0]
                    
                    if parameter == 0x15:
                        return {'error': 'No tag or CRC error'}
                        
            return None
            
        except:
            return None
            
    def stop_inventory(self):
        """停止轮询"""
        if self.serial.is_open:
            self.serial.close()
            
    def __del__(self):
        """析构函数,确保串口关闭"""
        if hasattr(self, 'serial') and self.serial.is_open:
            self.serial.close()
